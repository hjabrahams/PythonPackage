#mypackage
This library was created as an example of publishing Python packages.